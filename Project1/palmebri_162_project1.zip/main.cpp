/*****************
* Brian Palmer
* 10.5.16
* palmebri@oregonstate.edu
* Main file
****************/

#include "menu_function.hpp"

int main()
{
	int check = menu_function();

	return check;
}


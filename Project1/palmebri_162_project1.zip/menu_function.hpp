/*************
* Brian Palmer
* 10.5.16
* palmebri@oregonstate.edu
* Header File for the menu function
************/
#ifndef _MENUF_
#define _MENUF_

int menu_function();

#endif

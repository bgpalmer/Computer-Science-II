/***************
* brian palmer
* 10.20.16
* palmebri@oregonstate.edu
* reverse function declaration
****************/

#ifndef _REVERSE_
#define _REVERSE_

#include <iostream>
#include <string>
using std::string;
using std::cin;
using std::cout;
using std::endl;

void reverse_string(string);

#endif

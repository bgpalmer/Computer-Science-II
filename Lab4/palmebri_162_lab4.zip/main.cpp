/*********
* brian palmer
* 10.20.16
* palmebri@oregonstate.edu
* main program
*************/


#include "menu_functions.hpp"
#include "triangular.hpp"
#include "sum.hpp"
#include "reverse_string.hpp"

int main ()
{
        int response;
        do
        {
                response = integer_menu();
                string input;
                if (response == 1)
                {
                        cout << "Enter a string" << endl;
                        string input = facilitateNameInput();
                        input = "\n" + input;
                        cout << " ==> ";
                        reverse_string(input);
                }
                else if (response == 2)
                {
                        cout << "How many numbers do you want to enter? (5 - 50)" << endl;
                        int size = facilitateIntInput(5,51);
                        cout << "Enter an integer between 0 and 32000" << endl;
                        int * ptr = new int [size];
                        for (int i = 0; i < size; i++)
                                ptr[i] = facilitateIntInput(0, 32001);
                        cout << " ==> Sum is " << sum(ptr, size) << endl;
                        delete [] ptr;
                }
                else if (response == 3)
                {
                        cout << "Triangle Number calculator, what does N equal?" << endl;
                        int N = facilitateIntInput(1,30001);
                        cout << " ==> Triangular number is " << triangular(N) << endl;
                }

                else
                        cout << "Goodbye!" << endl;
        } while (response != 4);

        return 0;
}

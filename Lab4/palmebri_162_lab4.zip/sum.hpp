/************
* brian palmer
* 10.20.16
* palmebri@oregonstate.edu
* sum template
*************/

#ifndef _SUM_
#define _SUM_

int sum(int arr [], int);

#endif

/*************
* brian palmer
* 10.20.16
* palmebri@oregonstate.edu
* triangular function template
***************/

#ifndef _TRIANGLE
#define _TRIANGLE

int triangular(int);

#endif
